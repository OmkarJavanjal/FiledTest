import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ErrorPageComponent } from './common/error-page/error-page.component';
import { HeaderComponent } from './core/header/header.component';
import { FooterComponent } from './core/footer/footer.component';
import {AppRoutingModule} from './app.routing.module';
import {HttpClientModule} from '@angular/common/http';
import {StoreModule} from '@ngrx/store';
import {metaReducers, reducer} from './store/root.reducer';
import {EffectsModule} from '@ngrx/effects';
import {AppRootEffects} from './store/effects/root/effects';
import {StoreRouterConnectingModule} from '@ngrx/router-store';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {NgIdleKeepaliveModule} from '@ng-idle/keepalive';
import {PaymentsEffects} from './store/effects/payments/effects';
import { HomeComponent } from './core/home/home.component';
import {ReactiveFormsModule} from '@angular/forms';
import { FutureDateDirective } from './features/shared/future-date.directive';
import {RouterEffects} from './store/effects/router.effects';

@NgModule({
  declarations: [
    AppComponent,
    ErrorPageComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    FutureDateDirective,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    StoreModule.forRoot({ appState: reducer }, { metaReducers }),
    EffectsModule.forRoot([
      AppRootEffects,
      PaymentsEffects,
      RouterEffects
    ]),
    StoreRouterConnectingModule.forRoot(),
    StoreDevtoolsModule.instrument(/*{ logOnly: environment.production }*/),
    /*NgIdleKeepaliveModule.forRoot(),*/
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
