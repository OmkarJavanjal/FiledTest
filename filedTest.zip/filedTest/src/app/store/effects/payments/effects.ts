import { Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import {switchMap, catchError, delay} from 'rxjs/operators';
import {of, EMPTY} from 'rxjs';

import { AppActions } from '../../actions/root.actions';
import { RouterActions } from '../../actions/router.actions';
import {PaymentsService} from '../../../features/payments/payments.service';


@Injectable()
export class PaymentsEffects {

    setPaymentsInfo$ = createEffect(() => this.actions$.pipe(
        ofType(AppActions.payments.setPaymentInfo),
        switchMap(action => this.paymentsService.updatePaymentsInfo(action.payload)
            .pipe(
                switchMap(resp => {
                    console.log('resp ', resp);
                    if(resp) {
                        return of(AppActions.payments.updatePaymentInfo({ payload: resp }),
                          RouterActions.Go({payload: {path: ['/']}}));
                    } else {
                        return of(RouterActions.Go({payload: {path: ['/errorpage']}}));
                    }
                }),
                catchError(error => EMPTY)
            )
        )
    ));

    constructor(private actions$: Actions, private paymentsService: PaymentsService) {}
}
