import { Draft } from 'immer';
import { AppActions } from '../../actions/root.actions';
import * as helpers from '../helper-functions';
import AppState from '../../state/app-state.model';

const updatePaymentInfo = helpers.produceOn(AppActions.payments.updatePaymentInfo, (draft: Draft<AppState>, { payload }) => {
    draft.userDetails = {
        ...draft?.userDetails,
      paymentInfo: payload
    }
});

export const PaymentsReducers = [
  updatePaymentInfo
];
