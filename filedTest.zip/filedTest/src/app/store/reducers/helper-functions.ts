import { FunctionWithParametersType, ActionCreator, ActionType } from '@ngrx/store/src/models';
import produce, { Draft } from 'immer';
import { on } from '@ngrx/store';


// This function incorporates immer's produce function to ensure state immutability on updates. It wrap's NgRx's on()
export function produceOn<Type extends string, C extends FunctionWithParametersType<any, object>, AppState>(
    actionType: ActionCreator<Type, C>,
    callback: (draft: Draft<AppState>, action: ActionType<ActionCreator<Type, C>>) => any,
) { return on(actionType, (state: AppState, action): AppState => produce(state, (draft) => callback(draft, action)));}

export const updateArrayById = (array: Array<any>, item: any, idField: string): Array<any> => {
    const index = array.findIndex(i => i[idField] === item[idField]);
        if(index !== -1 ) {
            array[index] = item;
        }
        return array;
}

export const updateObjectPropertyById = (object: Object, item: any, idField: string): Object => {
    object[idField] = item;
    return object;
}