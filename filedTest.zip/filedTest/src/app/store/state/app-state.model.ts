export default interface AppState {
        userDetails: any
}
