import { MetaReducer, ActionReducer, createReducer, Action } from '@ngrx/store';
import { localStorageSync } from 'ngrx-store-localstorage';

import AppState from './state/app-state.model';
import {PaymentsReducers} from './reducers/payments/reducers';
import {AppRootActionTypes} from './actions/root/actions';

export const initialState = {
  userDetails: {}
};

const appReducer = createReducer(
    initialState,
    ...PaymentsReducers
);

export function reducer(state: AppState | undefined, action: Action) {
    return appReducer(state, action);
}

export function localStorageSyncReducer(reducer: ActionReducer<any>): ActionReducer<any> {
    return localStorageSync({ keys: ['appState'], rehydrate: true, storage: sessionStorage})(reducer);
}

export function resetAppState(reducer: ActionReducer<any>) : ActionReducer<any> {
    return function(state, action) {
        if(action.type === AppRootActionTypes.resetAppState) {
            state = initialState;
        }
        return reducer(state, action);
    }
}

export const metaReducers: Array<MetaReducer<any, any>> = [localStorageSyncReducer, resetAppState];
