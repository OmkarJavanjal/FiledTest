import { createSelector } from '@ngrx/store';
import AppState from '../state/app-state.model';

const getUserDetailsStateFn = (state: AppState) => state['appState'].userDetails;

export const getUserDetailsState = createSelector(
  getUserDetailsStateFn,
  (state: any) => state

);

export const getPaymentInfo = createSelector(
  getUserDetailsStateFn,
  (state: any) => state?.paymentInfo
);


export const Selectors = {
  getUserDetailsState,
  getPaymentInfo
};
