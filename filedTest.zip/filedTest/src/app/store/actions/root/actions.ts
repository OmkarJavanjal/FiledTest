import { createAction, props, Action } from "@ngrx/store";

export enum AppRootActionTypes {
    chainedActions = '[App] Chaining Actions',
    resetAppState = '[App] Reset App State'
}

export const chainedActions = createAction(AppRootActionTypes.chainedActions, props<{ payload: Array<Action>}>());
export const resetAppState = createAction(AppRootActionTypes.resetAppState);

export const RootActions = {
    chainedActions,
    resetAppState
}
