import {createAction, props} from '@ngrx/store';

export enum PaymentsFlowActionTypes {
  setPaymentInfo = '[Payment] Set Payment Info',
  updatePaymentInfo = '[Payment] Update Payment Info',

}

export const setPaymentInfo = createAction(PaymentsFlowActionTypes.setPaymentInfo, props<{ payload: any }>());
export const updatePaymentInfo = createAction(PaymentsFlowActionTypes.updatePaymentInfo, props<{ payload: any }>());

export const PaymentsActions = {
  setPaymentInfo,
  updatePaymentInfo
};
