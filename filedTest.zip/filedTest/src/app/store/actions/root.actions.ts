import * as rootActions from './root/actions';
import * as paymentssActions from './payments/actions';

export const AppActions = {
  root: rootActions.RootActions,
  payments: paymentssActions.PaymentsActions
};
