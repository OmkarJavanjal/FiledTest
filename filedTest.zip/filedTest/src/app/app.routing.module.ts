import { NgModule, } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import {ErrorPageComponent} from './common/error-page/error-page.component';
import {HomeComponent} from './core/home/home.component';

const routes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'payment', loadChildren: () => import('./features/payments/payments.module').then(m => m.PaymentsModule) },
  /*{ path: 'policies', loadChildren: () => import('./features/policies/policies.module').then(m => m.PoliciesModule)},*/
  { path: 'errorpage', component: ErrorPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
