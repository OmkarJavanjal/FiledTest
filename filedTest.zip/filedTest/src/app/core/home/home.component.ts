import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import AppState from '../../store/state/app-state.model';
import {Store} from '@ngrx/store';
import {getPaymentInfo} from '../../store/selectors/selectors';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {

  subscriptions$: Subscription[] = [];
  paymentInfo;

  constructor(private router: Router,
              private store: Store<AppState>) { }

  ngOnInit(): void {
    this.subscriptions$.push(this.store.select(getPaymentInfo).subscribe(state => {
      console.log('state: ', state);
      this.paymentInfo = state;
    }));
  }

  navigateToPayments() {
    this.router.navigate(['/payment']);
  }

  ngOnDestroy(): void {
    //handling memory leak issues
    this.subscriptions$.forEach(sub => sub.unsubscribe());
  }

}
