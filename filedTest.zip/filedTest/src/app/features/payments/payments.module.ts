import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymetsLandingComponent } from './paymets-landing/paymets-landing.component';
import {PaymentsRoutingModule} from './payments-routing.module';
import {ReactiveFormsModule} from '@angular/forms';



@NgModule({
  declarations: [PaymetsLandingComponent],
  imports: [
    CommonModule,
    PaymentsRoutingModule,
    ReactiveFormsModule
  ]
})
export class PaymentsModule { }
