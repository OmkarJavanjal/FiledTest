import {RouterModule, Routes} from '@angular/router';
import {PaymetsLandingComponent} from './paymets-landing/paymets-landing.component';
import {NgModule} from '@angular/core';

const routes: Routes = [
  {path: '', component: PaymetsLandingComponent, pathMatch: 'full'},
  {path: '', redirectTo: '', pathMatch: 'full'}
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentsRoutingModule {}
