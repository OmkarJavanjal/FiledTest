import { Injectable } from '@angular/core';
import {Observable, of, Subject} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {delay, map} from 'rxjs/operators';
import {MOCKPAYMENTS} from '../../mock-data/mock-payment-update';

@Injectable({
  providedIn: 'root'
})
export class PaymentsService {

  public isResponseSuccess$ = new Subject();

  constructor(private http: HttpClient) {
  }

  updatePaymentsInfo(paymentObj): Observable<any> {
    /*return this.http.post<any>('payment/update', paperlessObj).pipe( //`${env.PAPERLESS}`
        map(res => {
          return res;
        })
    );*/
    return of(paymentObj).pipe(delay(3000));
    //return of(MOCKPAYMENTS).pipe(delay(3000))
  }
}
