import { Component, OnInit } from '@angular/core';
import {Store} from '@ngrx/store';
import AppState from '../../../store/state/app-state.model';
import {setPaymentInfo} from '../../../store/actions/payments/actions';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {dateValidator} from '../../shared/date-validator';
import {minAmountValidator} from '../../shared/min-amount-validator';


@Component({
  selector: 'app-paymets-landing',
  templateUrl: './paymets-landing.component.html',
  styleUrls: ['./paymets-landing.component.scss']
})
export class PaymetsLandingComponent implements OnInit {
  paymentForm: FormGroup;
  ccdNum = '';
  cardHolderName = '';
  expirationDate = '';
  ccvNum = '';
  amnt = '';
  constructor(  private _formBuilder: FormBuilder,
                private store: Store<AppState>) { }

  ngOnInit(): void {
    this.setFormBuilder();
  }

  setFormBuilder() {
    this.paymentForm = this._formBuilder.group({
      ccNumber: [this.ccdNum, [Validators.required, Validators.pattern('[0-9]+')]],
      cardHolder: [ this.cardHolderName, [Validators.required]],
      expDate: [this.expirationDate,[Validators.required, dateValidator]],
      ccv: [this.ccvNum, [Validators.required, Validators.minLength(3), Validators.maxLength(3), Validators.pattern('[0-9]+')]],
      amount: [this.amnt,[Validators.required, minAmountValidator, Validators.pattern('[0-9]+')]]
    });
  }

  get ccNumber() { return this.paymentForm.get('ccNumber'); };
  get cardHolder() { return this.paymentForm.get('cardHolder'); };
  get expDate() { return this.paymentForm.get('expDate'); };
  get ccv() { return this.paymentForm.get('ccv'); };
  get amount() { return this.paymentForm.get('amount'); };


  save() {
    console.log('paymentForm: ', this.paymentForm.value);
    this.store.dispatch(setPaymentInfo({payload: this.paymentForm.value}));
  }

}
