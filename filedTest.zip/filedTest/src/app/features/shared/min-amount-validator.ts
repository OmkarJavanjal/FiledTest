import {AbstractControl} from '@angular/forms';

export function minAmountValidator(control: AbstractControl): {[key: string]: boolean} {
  console.log("forbidden: ", control.value);
  return Number(control.value) <= 0 ? {'forbiddenAmount': true} : null;
}
