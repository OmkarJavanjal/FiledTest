import { Directive } from "@angular/core";
import {
  AbstractControl,
  NG_VALIDATORS,
  ValidationErrors,
  Validator,
  ValidatorFn
} from "@angular/forms";

export function forbiddenDateValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const currentDate = new Date().getTime();
    const newDate = new Date(control.value).getTime();
    return currentDate > newDate ? {forbiddenName: {value: control.value}} : null;

  };
}

@Directive({
  selector: "[appFutureDate]",
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: FutureDateDirective,
      multi: true
    }
  ]
})
export class FutureDateDirective implements Validator {

  validate(control: AbstractControl): ValidationErrors | null {
    return control.value
      ? forbiddenDateValidator()(control)
      : null;
  }
}
