import {AbstractControl} from '@angular/forms';

export function dateValidator(control: AbstractControl): {[key: string]: boolean} {
  const currentDate = new Date().getTime();
  const newDate = new Date(control.value).getTime();
  console.log("forbidden: ", currentDate, newDate, control.value, currentDate > newDate);

  return currentDate > newDate ? {'forbiddenDate': true} : null;
}
