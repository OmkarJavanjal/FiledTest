export const MOCKPAYMENTS = {
  ccNumber: '12345678',
  cardHolder: 'John',
  expirationDate: '12/12/2021',
  cvv: '123',
  amount: 100
};
